
import folder_scanning
import unittest

class test_folder_scanning(unittest.TestCase):
    def __init__(self):
        self.fs = folder_scanning()
    
    def test_001(self):
        pass