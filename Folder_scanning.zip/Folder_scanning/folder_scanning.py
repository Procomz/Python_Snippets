import os

class folder_scanning():
    def __init__(self):
        pass
    
    def scan(self, path):
        # gets current directory
        dirname = os.path.dirname(__file__) + r"/"
        test_folder = os.path.join(dirname, path)
        
##        print(os.listdir(test_folder))
#        for root, dirs, files in os.walk(test_folder):
#            print(root)
#            print(dirs)
#            print(files)
#            for di in dirs:
#                for file in files:
#    #                print(os.path.join(root, file))
        
        file_set = set()

        for dir_, _, files in os.walk(test_folder):
            for file_name in files:
                rel_dir = os.path.relpath(dir_, dirname)
                rel_file = os.path.join(rel_dir, file_name)
                file_set.add(rel_file)
        print(file_set)

if __name__ == '__main__':
    fs = folder_scanning()
    fs.scan(r"test_data/data1")
    